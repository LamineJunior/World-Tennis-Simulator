
from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('database.sqlite')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/players')
def players():
    conn = get_db_connection()
    players = conn.execute('SELECT * FROM players').fetchall()
    conn.close()
    return render_template('players.html', players=players)

@app.route('/add_player', methods=('GET', 'POST'))
def add_player():
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        nationality = request.form['nationality']
        surface_pref = request.form['surface_pref']
        forehand = request.form['forehand']
        backhand = request.form['backhand']
        serve = request.form['serve']
        mental = request.form['mental']
        speed = request.form['speed']
        conn = get_db_connection()
        conn.execute('INSERT INTO players (name, age, nationality, surface_pref, forehand, backhand, serve, mental, speed) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                     (name, age, nationality, surface_pref, forehand, backhand, serve, mental, speed))
        conn.commit()
        conn.close()
        return redirect('/players')
    return render_template('add_player.html')

@app.route('/edit_player/<int:id>', methods=('GET', 'POST'))
def edit_player(id):
    conn = get_db_connection()
    player = conn.execute('SELECT * FROM players WHERE id = ?', (id,)).fetchone()
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        nationality = request.form['nationality']
        surface_pref = request.form['surface_pref']
        forehand = request.form['forehand']
        backhand = request.form['backhand']
        serve = request.form['serve']
        mental = request.form['mental']
        speed = request.form['speed']
        conn.execute('UPDATE players SET name = ?, age = ?, nationality = ?, surface_pref = ?, forehand = ?, backhand = ?, serve = ?, mental = ?, speed = ? WHERE id = ?',
                     (name, age, nationality, surface_pref, forehand, backhand, serve, mental, speed, id))
        conn.commit()
        conn.close()
        return redirect('/players')
    conn.close()
    return render_template('edit_player.html', player=player)

@app.route('/delete_player/<int:id>')
def delete_player(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM players WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect('/players')

if __name__ == '__main__':
    app.run(debug=True)
